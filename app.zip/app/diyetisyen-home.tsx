import { View, Text, StyleSheet } from 'react-native';

export default function DiyetisyenHomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Diyetisyen Paneli 👩‍⚕️</Text>
      <Text style={styles.subtitle}>Riskli hastalar burada listelenecek.</Text>
      
      {/* İleride buraya "Kırmızı/Sarı/Yeşil" kartları ekleyeceğiz */}
      <View style={styles.demoCard}>
        <Text>⚠️ Ayşe Yılmaz (Riskli)</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f5f5' },
  title: { fontSize: 24, fontWeight: 'bold', color: '#333' },
  subtitle: { fontSize: 16, color: '#666', marginTop: 10 },
  demoCard: { marginTop: 30, padding: 20, backgroundColor: '#ffebee', borderRadius: 10, borderWidth: 1, borderColor: '#ef5350' }
});