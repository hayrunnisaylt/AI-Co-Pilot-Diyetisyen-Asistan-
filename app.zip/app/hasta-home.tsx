import { useState } from 'react';
import { StyleSheet, Text, View, Button, Image, ActivityIndicator, ScrollView, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios';

export default function HastaHomeScreen() {
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Android Emülatör için 10.0.2.2, Gerçek telefon için bilgisayar IP'si
  const API_URL = "http://10.0.2.2:8000/tahmin-et";

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (permissionResult.granted === false) {
      Alert.alert("İzin Gerekli", "Galeriye erişmek için izin vermelisiniz.");
      return;
    }

    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        // DÜZELTME: 'MediaType' yerine tekrar 'MediaTypeOptions' kullanıyoruz.
        // Bu, "undefined" hatasını kesin olarak çözer.
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled) {
        setImage(result.assets[0].uri);
        uploadImage(result.assets[0].uri);
      }
    } catch (error) {
      console.log("Resim seçme hatası:", error);
      Alert.alert("Hata", "Resim seçilirken bir sorun oluştu.");
    }
  };

  const uploadImage = async (uri: string) => {
    setLoading(true);
    setResult(null);

    const formData = new FormData();
    // @ts-ignore
    formData.append('file', {
      uri: uri,
      name: 'yemek.jpg',
      type: 'image/jpeg',
    });

    try {
      // console.log("Sunucuya gönderiliyor...");
      const response = await axios.post(API_URL, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setResult(response.data);
    } catch (error) {
      console.error(error);
      Alert.alert("Bağlantı Hatası", "Sunucuya ulaşılamadı.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Bugün Ne Yedin? 🍎</Text>

      <View style={styles.card}>
        {image ? (
          <Image source={{ uri: image }} style={styles.image} />
        ) : (
          <View style={styles.placeholder}>
            <Text style={styles.placeholderText}>Fotoğraf Yok</Text>
          </View>
        )}

        <View style={styles.buttonContainer}>
          <Button title="Öğün Ekle 📸" onPress={pickImage} color="#4CAF50" />
        </View>
      </View>

      {loading && <ActivityIndicator size="large" color="#4CAF50" style={{ marginTop: 20 }} />}

      {result && (
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>AI Analizi:</Text>
          {result.sonuc && result.sonuc.map((item: any, index: number) => (
            <View key={index} style={styles.resultRow}>
              <Text style={styles.foodName}>🍽️ {item.yemek_adi}</Text>
              <Text style={styles.confidence}>%{Math.round(item.guven_orani * 100)}</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, backgroundColor: '#f0f2f5', alignItems: 'center', padding: 20 },
  header: { fontSize: 24, fontWeight: 'bold', color: '#1a1a1a', marginBottom: 20 },
  card: { backgroundColor: 'white', borderRadius: 15, padding: 15, width: '100%', alignItems: 'center', elevation: 3 },
  image: { width: 280, height: 280, borderRadius: 10 },
  placeholder: { width: 280, height: 280, backgroundColor: '#e1e4e8', borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  placeholderText: { color: '#888' },
  buttonContainer: { marginTop: 15, width: '100%' },
  resultCard: { marginTop: 20, backgroundColor: '#ffffff', width: '100%', borderRadius: 15, padding: 20, borderLeftWidth: 6, borderLeftColor: '#4CAF50', elevation: 2 },
  resultTitle: { fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  resultRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 },
  foodName: { fontSize: 16, color: '#333' },
  confidence: { fontSize: 16, fontWeight: 'bold', color: '#4CAF50' },
});