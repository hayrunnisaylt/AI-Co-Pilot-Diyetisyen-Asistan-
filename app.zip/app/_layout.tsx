import { Stack } from 'expo-router';

export default function RootLayout() {
  return (
    <Stack>
      {/* name="index" -> app/index.tsx dosyasını işaret eder.
        headerShown: false -> Varsayılan üst başlık çubuğunu gizler, daha temiz görünür.
      */}
      <Stack.Screen 
        name="index" 
        options={{ 
          title: 'AI Diyetisyen', 
          headerShown: false 
        }} 
      />
    </Stack>
  );
}