import { useState } from 'react';
import { StyleSheet, Text, View, Button, Image, ActivityIndicator, ScrollView, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios';

export default function HomeScreen() {
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Android Emülatör için IP Adresi (Sabit)
  const API_URL = "http://10.0.2.2:8000/tahmin-et";

  const pickImage = async () => {
    // İzin iste
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (permissionResult.granted === false) {
      Alert.alert("İzin Gerekli", "Galeriye erişmek için izin vermelisiniz.");
      return;
    }

    // Fotoğraf seç
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaType.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
      // Seçileni hemen sunucuya gönder
      uploadImage(result.assets[0].uri);
    }
  };

  const uploadImage = async (uri: string) => {
    setLoading(true);
    setResult(null);

    const formData = new FormData();
    // @ts-ignore
    formData.append('file', {
      uri: uri,
      name: 'yemek.jpg',
      type: 'image/jpeg',
    });

    try {
      console.log("Sunucuya gönderiliyor...");
      const response = await axios.post(API_URL, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      console.log("Başarılı:", response.data);
      setResult(response.data);
    } catch (error) {
      console.error(error);
      Alert.alert("Bağlantı Hatası", "Sunucuya ulaşılamadı. Backend'in açık olduğundan emin olun.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>AI Diyetisyen 🥗</Text>

      <View style={styles.card}>
        {image ? (
          <Image source={{ uri: image }} style={styles.image} />
        ) : (
          <View style={styles.placeholder}>
            <Text style={styles.placeholderText}>Fotoğraf Yok</Text>
          </View>
        )}

        <View style={styles.buttonContainer}>
          <Button title="Fotoğraf Seç" onPress={pickImage} />
        </View>
      </View>

      {loading && <ActivityIndicator size="large" color="#2196F3" style={{ marginTop: 20 }} />}

      {result && (
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>Analiz Sonucu:</Text>
          {result.sonuc && result.sonuc.map((item: any, index: number) => (
            <View key={index} style={styles.resultRow}>
              <Text style={styles.foodName}>🍽️ {item.yemek_adi}</Text>
              <Text style={styles.confidence}>%{Math.round(item.guven_orani * 100)}</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, backgroundColor: '#f0f2f5', alignItems: 'center', padding: 20, paddingTop: 60 },
  header: { fontSize: 28, fontWeight: 'bold', color: '#1a1a1a', marginBottom: 20 },
  card: { backgroundColor: 'white', borderRadius: 15, padding: 15, width: '100%', alignItems: 'center', shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  image: { width: 280, height: 280, borderRadius: 10 },
  placeholder: { width: 280, height: 280, backgroundColor: '#e1e4e8', borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  placeholderText: { color: '#888', fontSize: 16 },
  buttonContainer: { marginTop: 15, width: '100%' },
  resultCard: { marginTop: 20, backgroundColor: '#ffffff', width: '100%', borderRadius: 15, padding: 20, borderLeftWidth: 6, borderLeftColor: '#4CAF50', elevation: 2 },
  resultTitle: { fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  resultRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 },
  foodName: { fontSize: 18, color: '#333' },
  confidence: { fontSize: 18, fontWeight: 'bold', color: '#4CAF50' },
});