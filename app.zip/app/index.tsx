import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function WelcomeScreen() {
  const router = useRouter();

  // Geliştirme aşamasındayken eski girişleri silmek istersen bu bloğu açabilirsin:
  /*
  useEffect(() => {
    AsyncStorage.clear();
  }, []);
  */

  return (
    <LinearGradient
      // Tasarımındaki o soft sarımtırak/beyaz geçişi
      colors={['#fdfcfb', '#e2d1c3']} 
      style={styles.container}
    >
      <SafeAreaView style={styles.content}>
        
        {/* Başlık Kısmı */}
        <View style={styles.headerContainer}>
          <Text style={styles.title}>Merhaba !</Text>
          <Text style={styles.title}>Hoşgeldin</Text>
          <Text style={styles.subtitle}>Giriş türünüzü seçiniz.</Text>
        </View>

        {/* Butonlar Kısmı */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity 
            style={styles.button}
            activeOpacity={0.8}
            // Şimdilik test için ikisini de aynı login sayfasına yönlendiriyorum. 
            // Daha sonra /login?role=diyetisyen şeklinde parametre yollayacağız.
            onPress={() => router.push('/register')} 
          >
            <Text style={styles.buttonText}>Diyetisyen Girişi</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.button}
            activeOpacity={0.8}
            onPress={() => router.push('/register')}
          >
            <Text style={styles.buttonText}>Danışan Girişi</Text>
          </TouchableOpacity>
        </View>

      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  headerContainer: {
    marginBottom: 60,
  },
  title: {
    fontSize: 42,
    fontWeight: '900',
    color: '#2d2d3a', // Tasarımındaki koyu lacivert/gri tonu
    letterSpacing: -1,
  },
  subtitle: {
    fontSize: 16,
    color: '#555',
    marginTop: 15,
    fontWeight: '500',
  },
  buttonContainer: {
    gap: 20, // Butonlar arası boşluk
  },
  button: {
    backgroundColor: '#343541', // Tasarımındaki buton rengi
    paddingVertical: 18,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5, // Android gölgesi
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '700',
  },
});